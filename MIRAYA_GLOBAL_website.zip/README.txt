MIRAYA GLOBAL - Website
========================
Files:
- index.html : complete website

The website works without buying a domain. It can be opened locally or uploaded to a free static hosting service such as GitHub Pages.

Business details used:
Company: MIRAYA GLOBAL
Phone/WhatsApp: +91 63772 39815

To publish for free:
1. Create a free GitHub account.
2. Create a new public repository (for example: miraya-global).
3. Upload index.html.
4. Enable GitHub Pages from repository Settings > Pages.
5. GitHub will provide a free address such as https://username.github.io/miraya-global/

A custom domain is optional and can be connected later.
